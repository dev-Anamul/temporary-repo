import React from "react";

function About() {
  return <div>about page page</div>;
}

export default About;
